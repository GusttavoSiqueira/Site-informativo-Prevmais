import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from '@/pages/HomePage';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import Layout from '@/components/Layout';

function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/politicas-de-privacidade" element={<PrivacyPolicy />} />
      </Route>
    </Routes>
  );
}

export default App;