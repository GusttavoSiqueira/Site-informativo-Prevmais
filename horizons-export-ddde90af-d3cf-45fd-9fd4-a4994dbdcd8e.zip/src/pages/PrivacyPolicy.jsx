import React from 'react';
import { Helmet } from 'react-helmet';
import { ShieldCheck, Lock, Globe, FileText, HeartHandshake as Handshake, MessageSquare, HeartHandshake } from 'lucide-react';

const PrivacyPolicy = () => {
  const policies = [
    {
      icon: <ShieldCheck className="w-8 h-8 text-emerald-500" />,
      title: "1. Código de Ética e Conduta",
      content: "O Código de Ética e Conduta da Prevmais estabelece os princípios, valores e comportamentos esperados de todos os colaboradores, parceiros e prestadores de serviço. A empresa preza pela integridade, transparência, respeito, responsabilidade social e profissionalismo em todas as suas relações. Todos os representantes da Prevmais devem agir de forma ética, cumprindo as leis e regulamentos aplicáveis e mantendo sigilo sobre informações internas e de clientes."
    },
    {
      icon: <Lock className="w-8 h-8 text-emerald-500" />,
      title: "2. Política de Privacidade de Dados",
      content: "A Prevmais respeita a privacidade e a proteção dos dados pessoais de todos os usuários, clientes, colaboradores e parceiros. Os dados coletados são utilizados apenas para finalidades legítimas e previamente informadas, como o fornecimento de serviços, comunicação institucional e cumprimento de obrigações legais. Todos os dados são tratados em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018), com medidas técnicas e administrativas para garantir segurança, confidencialidade e integridade das informações."
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-emerald-500" />,
      title: "3. Política de Segurança da Informação",
      content: "A Prevmais adota controles e procedimentos de segurança destinados a proteger as informações contra perda, mau uso, acesso não autorizado, divulgação ou alteração indevida. O acesso às informações é restrito a profissionais devidamente autorizados e treinados, de acordo com suas funções e responsabilidades. A empresa realiza auditorias periódicas e atualizações de seus sistemas para reforçar continuamente a proteção dos dados sob sua guarda."
    },
    {
      icon: <Globe className="w-8 h-8 text-emerald-500" />,
      title: "4. Política de Transferência Internacional de Dados",
      content: "Em alguns casos, a Prevmais poderá transferir dados pessoais para outros países, sempre observando o cumprimento das normas de proteção de dados e garantindo um nível de segurança equivalente ao exigido pela legislação brasileira. As transferências ocorrerão apenas quando necessárias à execução de contratos, ao cumprimento de obrigações legais ou mediante consentimento expresso do titular dos dados."
    },
    {
      icon: <FileText className="w-8 h-8 text-emerald-500" />,
      title: "5. Termos Gerais de Uso de Plataformas, Soluções e Recursos",
      content: "Ao acessar e utilizar as plataformas, sistemas e serviços da Prevmais, o usuário declara estar ciente e de acordo com os presentes termos de uso. É de responsabilidade do usuário o uso adequado dos recursos disponibilizados, sendo vedado qualquer tipo de conduta que possa comprometer a integridade, disponibilidade ou segurança das plataformas. A Prevmais reserva-se o direito de suspender ou restringir o acesso de usuários que descumprirem estas condições."
    },
    {
      icon: <Handshake className="w-8 h-8 text-emerald-500" />,
      title: "6. Política Anticorrupção",
      content: "A Prevmais adota uma postura de tolerância zero em relação a qualquer ato de corrupção, fraude ou suborno. É proibido oferecer, prometer, autorizar ou receber vantagens indevidas que possam influenciar decisões comerciais ou institucionais. Todos os colaboradores e parceiros devem agir com honestidade e conformidade com as leis anticorrupção vigentes, inclusive a Lei nº 12.846/2013 (Lei Anticorrupção Empresarial)."
    },
    {
      icon: <HeartHandshake className="w-8 h-8 text-emerald-500" />,
      title: "7. Tratativas de Dados Sensíveis",
      content: "Os dados sensíveis — como informações de saúde, origem racial, opinião política, convicção religiosa, dados biométricos, entre outros — são tratados pela Prevmais com nível máximo de cuidado e proteção. O tratamento desses dados ocorre apenas mediante consentimento explícito do titular ou quando estritamente necessário para o cumprimento de obrigações legais. Tais informações são armazenadas em ambiente seguro e acessadas apenas por profissionais devidamente autorizados."
    },
    {
      icon: <MessageSquare className="w-8 h-8 text-emerald-500" />,
      title: "8. Ouvidoria",
      content: "A Ouvidoria da Prevmais é o canal oficial para receber manifestações, sugestões, elogios, denúncias e reclamações relacionadas aos serviços prestados e à conduta ética da organização. Todas as comunicações são tratadas com sigilo, imparcialidade e confidencialidade. Contato: ouvidoria@prevmais.com.br. Horário de atendimento: de segunda a sexta-feira, das 9h às 17h (horário de Brasília)."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Políticas de Privacidade | PREV+</title>
        <meta name="description" content="Conheça as políticas de privacidade, código de conduta e termos de uso da PREV+. Nosso compromisso com a sua segurança e transparência." />
      </Helmet>
      <div className="bg-slate-50">
        <div className="container mx-auto px-4 py-24 sm:py-32">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 tracking-tight">
                Políticas e Privacidade da <span className="text-emerald-600">Prevmais</span>
              </h1>
              <p className="mt-4 text-lg text-gray-600">
                Nosso compromisso com a ética, transparência e segurança da sua informação.
              </p>
            </div>

            <div className="space-y-10">
              {policies.map((policy, index) => (
                <div key={index} className="p-8 bg-white rounded-2xl shadow-md border border-gray-200/80">
                  <div className="flex items-start gap-6">
                    <div className="flex-shrink-0 bg-emerald-100 p-4 rounded-xl">
                      {policy.icon}
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-800 mb-2">{policy.title}</h2>
                      <p className="text-gray-700 leading-relaxed">{policy.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;