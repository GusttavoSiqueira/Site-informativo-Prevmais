import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'react-router-dom';
import Hero from '@/components/Hero';
import AboutPrev from '@/components/AboutPrev';
import WhatIsAuxilio from '@/components/WhatIsAuxilio';
import VideoSection from '@/components/VideoSection';
import WhoHasRight from '@/components/WhoHasRight';
import ValueRetroactivity from '@/components/ValueRetroactivity';
import RealExamples from '@/components/RealExamples';
import HowToRequest from '@/components/HowToRequest';
import LegalBasis from '@/components/LegalBasis';
import WhyChoosePrev from '@/components/WhyChoosePrev';
import Testimonials from '@/components/Testimonials';
import FinalCTA from '@/components/FinalCTA';
import LeadCaptureForm from '@/components/LeadCaptureForm';

const HomePage = () => {
  const { hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const element = document.querySelector(hash);
      if (element) {
        // We need a timeout to ensure the page has rendered before scrolling
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  }, [hash]);

  return (
    <>
      <Helmet>
        <title>PREV+ | Auxílio-Acidente - Descubra Seu Direito Agora</title>
        <meta name="description" content="Você pode ter direito ao Auxílio-Acidente. Descubra agora com a PREV+! Mesmo trabalhando, você pode receber uma renda vitalícia pelo INSS." />
      </Helmet>
      <main>
        <Hero />
        <div id="quem-somos">
          <AboutPrev />
        </div>
        <div id="o-que-e">
          <WhatIsAuxilio />
        </div>
        <VideoSection />
        <WhoHasRight />
        <ValueRetroactivity />
        <RealExamples />
        <HowToRequest />
        <LegalBasis />
        <WhyChoosePrev />
        <div id="depoimentos">
          <Testimonials />
        </div>
        <FinalCTA />
      </main>
      <div id="contato">
        <LeadCaptureForm />
      </div>
    </>
  );
};

export default HomePage;