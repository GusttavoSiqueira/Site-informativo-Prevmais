import React from 'react';
    import { Link } from 'react-router-dom';
    import { Facebook, Instagram, Youtube } from 'lucide-react';

    const Footer = () => {
      const handleScrollTo = (e, selector) => {
        e.preventDefault();
        const element = document.querySelector(selector);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      };

      return (
        <footer className="bg-gray-900 text-white pt-16 pb-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              
              <div>
                <img src="https://horizons-cdn.hostinger.com/ddde90af-d3cf-45fd-9fd4-a4994dbdcd8e/7e3451d09b68ffb4826aaea2cda1be4a.png" alt="PREV+ Logo" className="h-12 w-auto mb-4" />
                <p className="text-gray-400">Transformando burocracia em facilidade para garantir seus direitos.</p>
              </div>
              
              <div>
                <p className="font-bold text-lg mb-4">Links Rápidos</p>
                <ul className="space-y-2">
                  <li><a href="/#inicio" onClick={(e) => handleScrollTo(e, '#inicio')} className="text-gray-400 hover:text-white transition-colors">Início</a></li>
                  <li><a href="/#quem-somos" onClick={(e) => handleScrollTo(e, '#quem-somos')} className="text-gray-400 hover:text-white transition-colors">Quem Somos</a></li>
                  <li><a href="/#o-que-e" onClick={(e) => handleScrollTo(e, '#o-que-e')} className="text-gray-400 hover:text-white transition-colors">O que é o Auxílio</a></li>
                  <li><a href="/#depoimentos" onClick={(e) => handleScrollTo(e, '#depoimentos')} className="text-gray-400 hover:text-white transition-colors">Depoimentos</a></li>
                </ul>
              </div>
              
              <div>
                <p className="font-bold text-lg mb-4">Legal</p>
                <ul className="space-y-2">
                  <li><Link to="/politicas-de-privacidade" className="text-gray-400 hover:text-white transition-colors">Políticas de Privacidade</Link></li>
                </ul>
              </div>

              <div>
                <p className="font-bold text-lg mb-4">Siga-nos</p>
                <div className="flex space-x-4">
                  <a href="https://www.facebook.com/profile.php?id=61581918147823&locale=pt_BR" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Facebook size={24} /></a>
                  <a href="https://www.instagram.com/souprevmais" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Instagram size={24} /></a>
                  <a href="https://youtube.com/@souprevmais?si=YlbjXz5g2m9ZaLSR" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Youtube size={24} /></a>
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-500">
              <p>&copy; {new Date().getFullYear()} PREV+. Todos os direitos reservados.</p>
              <p className="text-sm mt-2">PREV+ CONSULTORIA LTDA / CNPJ: 63.065.598/0001-17
            </p>
            </div>

          </div>
        </footer>
      );
    };
    export default Footer;