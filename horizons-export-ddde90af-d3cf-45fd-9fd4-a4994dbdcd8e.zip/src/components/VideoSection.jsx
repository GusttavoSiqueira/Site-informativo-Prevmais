import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';

const VideoSection = () => {
  return (
    <section id="video-explicativo" className="py-20 bg-gray-100">
      <Helmet>
        <title>PREV+ | Vídeo Explicativo - Auxílio-Acidente</title>
        <meta name="description" content="Assista ao vídeo explicativo sobre o Auxílio-Acidente e entenda seus direitos com a PREV+." />
      </Helmet>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Entenda o Auxílio-Acidente em Detalhes!
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Assista ao nosso vídeo e descubra tudo o que você precisa saber sobre seus direitos.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative aspect-video max-w-4xl mx-auto rounded-xl shadow-2xl overflow-hidden"
        >
          <iframe
            className="absolute top-0 left-0 w-full h-full"
            src="https://www.youtube.com/embed/N-HJTDvSk5w?si=gghQJrwoJsU5rUs9"
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          ></iframe>
        </motion.div>
      </div>
    </section>
  );
};

export default VideoSection;