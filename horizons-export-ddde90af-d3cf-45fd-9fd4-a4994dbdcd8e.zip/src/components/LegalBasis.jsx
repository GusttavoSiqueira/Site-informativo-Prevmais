import React from 'react';
import { motion } from 'framer-motion';
import { Scale } from 'lucide-react';

const LegalBasis = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex items-center justify-center mb-8">
            <div className="bg-emerald-600 p-4 rounded-full">
              <Scale size={48} />
            </div>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-center mb-8">
            Fundamentação Legal
          </h2>

          <div className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-white/20">
            <div className="space-y-6">
              <div>
                <h3 className="text-2xl font-bold mb-3 text-emerald-400">Lei nº 8.213/1991 - Artigo 86</h3>
                <p className="text-white/90 text-lg leading-relaxed">
                  "O auxílio-acidente será concedido, como indenização, ao segurado quando, após consolidação das lesões decorrentes de acidente de qualquer natureza, resultarem sequelas que impliquem redução da capacidade para o trabalho que habitualmente exercia."
                </p>
              </div>

              <div className="border-t border-white/20 pt-6">
                <h3 className="text-2xl font-bold mb-3 text-emerald-400">Decreto nº 3.048/1999 - Artigo 104</h3>
                <p className="text-white/90 text-lg leading-relaxed">
                  Regulamenta a Previdência Social e estabelece os critérios para concessão do auxílio-acidente, incluindo os procedimentos de perícia médica e cálculo do benefício.
                  <br />
                  Trata-se de um benefício indenizatório devido ao segurado que, após consolidação das lesões decorrentes de acidente de qualquer natureza, apresentar redução permanente da capacidade para o trabalho habitual, ainda que mínima, conforme o entendimento pacificado pelo STJ no Tema 416.
                </p>
              </div>

              <div className="bg-emerald-600/20 p-6 rounded-lg mt-6">
                <p className="text-white text-center font-semibold text-lg">
                  Seu direito está garantido por lei. A PREV+ está aqui para ajudá-lo a conquistá-lo!
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default LegalBasis;