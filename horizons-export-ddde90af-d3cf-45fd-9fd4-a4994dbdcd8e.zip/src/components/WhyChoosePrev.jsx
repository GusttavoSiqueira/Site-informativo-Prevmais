import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Laptop, TrendingUp, Gift } from 'lucide-react';

const WhyChoosePrev = () => {
  const reasons = [
    {
      icon: Heart,
      title: 'Atendimento Humano',
      description: 'Equipe dedicada que entende suas necessidades e trata cada caso com empatia e respeito'
    },
    {
      icon: Laptop,
      title: 'Suporte Online',
      description: 'Atendimento rápido e eficiente via WhatsApp, sem necessidade de deslocamento'
    },
    {
      icon: TrendingUp,
      title: 'Alta Taxa de Aprovação',
      description: 'Experiência comprovada com centenas de casos aprovados em todo o Brasil'
    },
    {
      icon: Gift,
      title: 'Consultoria Gratuita',
      description: 'Análise inicial do seu caso sem custos, você só paga se ganhar o benefício'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Por que Escolher a PREV+?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Somos especialistas em garantir seus direitos previdenciários
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="bg-gradient-to-br from-emerald-50 to-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:-translate-y-2"
            >
              <div className="bg-emerald-600 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <reason.icon className="text-white" size={28} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{reason.title}</h3>
              <p className="text-gray-600 leading-relaxed">{reason.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChoosePrev;