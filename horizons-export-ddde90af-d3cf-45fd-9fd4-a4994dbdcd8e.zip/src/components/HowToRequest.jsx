import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Calendar, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HowToRequest = () => {
  const steps = [
    {
      icon: FileText,
      number: '1',
      title: 'Reunir a documentação necessária',
      description: (
        <>
          <ul className="list-inside list-disc text-gray-700">
            <li>Documento de identificação (RG ou CNH)</li>
            <li>CPF</li>
            <li>Comprovante de residência</li>
            <li>Carteira de Trabalho</li>
            <li>Laudos médicos, exames e atestados que comprovem as sequelas</li>
            <li>Comunicação de Acidente de Trabalho (CAT), se o acidente ocorreu no trabalho</li>
          </ul>
          <p className="mt-2">Compartilhe conosco e faremos uma análise completa e gratuita do seu caso.</p>
        </>
      )
    },
    {
      icon: Calendar,
      number: '2',
      title: 'Passar pela perícia médica do INSS',
      description: 'Cuidamos de todo o processo burocrático e agendamos sua perícia médica no INSS. Você receberá orientações completas sobre como se preparar. Você pode acompanhar o andamento pelo Meu INSS ou telefone 135.'
    },
    {
      icon: CheckCircle,
      number: '3',
      title: 'Acompanhamento e Conquista do seu Direito',
      description: 'Monitoramos seu processo do início ao fim, garantindo que você receba todos os valores devidos, incluindo retroativos e pagamentos mensais. Se o INSS negar seu pedido, podemos recorrer e garantir seus direitos!'
    }
  ];

  const handleWhatsApp = () => {
    window.open('https://wa.me/5511999999999?text=Olá! Preciso de ajuda para solicitar o Auxílio-Acidente.', '_blank');
  };

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Como Solicitar o Auxílio-Acidente
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Processo simples e descomplicado em apenas 3 passos
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto space-y-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex flex-col md:flex-row items-start gap-6">
                <div className="flex-shrink-0">
                  <div className="bg-gradient-to-br from-emerald-600 to-emerald-700 w-20 h-20 rounded-full flex items-center justify-center shadow-lg">
                    <step.icon className="text-white" size={36} />
                  </div>
                </div>
                
                <div className="flex-grow">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="bg-emerald-100 text-emerald-700 font-bold text-xl px-4 py-1 rounded-full">
                      {step.number}
                    </span>
                    <h3 className="text-2xl font-bold text-gray-900">{step.title}</h3>
                  </div>
                  <div className="text-lg leading-relaxed">{step.description}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Button
            onClick={handleWhatsApp}
            size="lg"
            className="bg-emerald-600 text-white hover:bg-emerald-700 text-lg px-8 py-6 font-semibold"
          >
            <XCircle className="mr-3" size={24} />
            Meu pedido foi negado. E agora? Fale com a PREV+!
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowToRequest;