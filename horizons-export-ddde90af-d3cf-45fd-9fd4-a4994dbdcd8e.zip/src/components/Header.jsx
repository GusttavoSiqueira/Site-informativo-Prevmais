import React, { useState, useEffect } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { useLocation, useNavigate } from 'react-router-dom';
    import { Menu, X } from 'lucide-react';

    const Header = () => {
      const [scrolled, setScrolled] = useState(false);
      const [isMenuOpen, setIsMenuOpen] = useState(false);
      const location = useLocation();
      const navigate = useNavigate();

      useEffect(() => {
        const handleScroll = () => {
          setScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
      }, []);

      useEffect(() => {
        if (isMenuOpen) {
          document.body.style.overflow = 'hidden';
        } else {
          document.body.style.overflow = 'auto';
        }
        return () => {
          document.body.style.overflow = 'auto';
        };
      }, [isMenuOpen]);

      const navLinks = [
        { name: 'Início', href: '#inicio' },
        { name: 'Quem Somos', href: '#quem-somos' },
        { name: 'O que é o Auxílio', href: '#o-que-e' },
        { name: 'Depoimentos', href: '#depoimentos' },
      ];

      const handleNavClick = (e, selector) => {
        e.preventDefault();
        setIsMenuOpen(false);
        if (location.pathname === '/') {
          const element = document.querySelector(selector);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        } else {
          navigate('/' + selector);
        }
      };
      
      const handleLogoClick = (e) => {
        e.preventDefault();
        setIsMenuOpen(false);
        if (location.pathname === '/') {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
          navigate('/');
        }
      };

      const menuVariants = {
        hidden: { x: '100%' },
        visible: { x: 0, transition: { type: 'tween', ease: 'circOut' } },
        exit: { x: '100%', transition: { type: 'tween', ease: 'circIn' } },
      };

      return (
        <>
          <motion.header
            initial={false}
            animate={{
              backgroundColor: scrolled || isMenuOpen ? 'rgba(255, 255, 255, 0.95)' : 'rgba(255, 255, 255, 0)',
              backdropFilter: scrolled || isMenuOpen ? 'blur(15px)' : 'blur(0px)',
              boxShadow: scrolled ? '0 6px 20px -5px rgba(0, 0, 0, 0.15)' : 'none',
            }}
            transition={{ duration: 0.3 }}
            className="fixed top-0 left-0 right-0 z-50 py-2 md:py-3"
          >
            <div className="container mx-auto px-4">
              <motion.div
                initial={false}
                animate={{ height: scrolled ? '65px' : '80px' }}
                transition={{ duration: 0.3 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center">
                  <a href="/" onClick={handleLogoClick} className="cursor-pointer z-50">
                    <img 
                      src="https://horizons-cdn.hostinger.com/ddde90af-d3cf-45fd-9fd4-a4994dbdcd8e/7e3451d09b68ffb4826aaea2cda1be4a.png" 
                      alt="PREV+ Logo"
                      className="h-12 w-auto md:h-14"
                    />
                  </a>
                </div>
                <nav className="hidden md:flex items-center space-x-8">
                  {navLinks.map((link) => (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link.href)}
                      className="font-semibold text-gray-700 relative cursor-pointer text-lg hover:text-emerald-600 transition-colors duration-300"
                      whileHover="hover"
                    >
                      {link.name}
                      <motion.div
                        className="absolute bottom-[-6px] left-0 right-0 h-1 bg-emerald-500 rounded-full"
                        variants={{
                          initial: { scaleX: 0, originX: 0 },
                          hover: { scaleX: 1, originX: 0 },
                        }}
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                        initial="initial"
                      />
                    </motion.a>
                  ))}
                </nav>
                <div className="hidden md:block">
                  <Button asChild className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-full text-lg shadow-lg hover:shadow-xl transition-all duration-300">
                    <a href="#contato" onClick={(e) => handleNavClick(e, '#contato')}>Fale com um Especialista</a>
                  </Button>
                </div>
                <div className="md:hidden">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="z-50 text-gray-800">
                    {isMenuOpen ? <X size={30} /> : <Menu size={30} />}
                  </button>
                </div>
              </motion.div>
            </div>
          </motion.header>

          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                variants={menuVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="fixed inset-0 bg-white z-40 pt-28 p-8 md:hidden"
              >
                <nav className="flex flex-col items-center justify-center h-full space-y-8">
                  {navLinks.map((link) => (
                    <a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link.href)}
                      className="font-bold text-gray-800 text-3xl"
                    >
                      {link.name}
                    </a>
                  ))}
                  <Button asChild size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-6 rounded-full text-xl shadow-lg mt-8">
                    <a href="#contato" onClick={(e) => handleNavClick(e, '#contato')}>Fale com um Especialista</a>
                  </Button>
                </nav>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      );
    };

    export default Header;