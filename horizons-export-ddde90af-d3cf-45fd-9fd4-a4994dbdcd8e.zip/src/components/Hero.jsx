import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
const Hero = () => {
  const handleSimulate = () => {
    const element = document.getElementById('quem-tem-direito');
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <section id="inicio" className="relative flex items-center pt-20 pb-12 overflow-hidden min-h-[calc(100vh-70px)]">
      <div className="absolute inset-0 z-0">
        <img className="w-full h-full object-cover" alt="Advogada sorrindo auxiliando um cliente com a perna engessada em um escritório moderno, simbolizando o suporte da PREV+ em auxílio-acidente" src="https://horizons-cdn.hostinger.com/ddde90af-d3cf-45fd-9fd4-a4994dbdcd8e/f7354c234f5c02b9309fdd4de204675f.png" />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-800/80 to-emerald-600/50"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <motion.h1 initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">Você pode ter direito ao Auxílio-Acidente. Descubra agora com a            PREV+</motion.h1>

          <motion.p initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.2
        }} className="text-xl md:text-2xl text-white/95 mb-8">
            Mesmo trabalhando, você pode receber uma renda vitalícia pelo INSS.
          </motion.p>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.4
        }} className="flex flex-col sm:flex-row gap-4">
            <Button onClick={handleSimulate} size="lg" className="bg-white text-emerald-700 hover:bg-emerald-100 text-lg px-8 py-6 font-semibold shadow-lg transform hover:scale-105 transition-transform">
              Simule seu Direito Agora <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>;
};
export default Hero;