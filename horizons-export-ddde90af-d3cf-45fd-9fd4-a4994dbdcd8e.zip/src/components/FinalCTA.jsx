import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { MessageCircle } from 'lucide-react';

    const FinalCTA = () => {
      const handleWhatsApp = () => {
        window.open('https://wa.me/5511921167221?text=Olá! Gostaria de saber mais sobre o Auxílio-Acidente.', '_blank');
      };

      return (
        <section className="py-20 bg-gradient-to-br from-emerald-600 to-emerald-700 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Não deixe seu direito para depois!
              </h2>
              <p className="text-2xl text-white/95 mb-8">
                A PREV+ cuida de tudo pra você. Fale agora com nossos especialistas!
              </p>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.3 }}
              >
                <Button
                  onClick={handleWhatsApp}
                  size="lg"
                  className="bg-white text-emerald-600 hover:bg-gray-100 text-xl px-12 py-8 font-bold shadow-2xl hover:shadow-3xl transition-all hover:scale-105"
                >
                  <MessageCircle className="mr-3" size={28} />
                  Falar com Especialista no WhatsApp
                </Button>
              </motion.div>

              <p className="text-white/80 mt-6 text-lg">
                Atendimento rápido e gratuito • Resposta em minutos
              </p>
            </motion.div>
          </div>
        </section>
      );
    };

    export default FinalCTA;