import React from 'react';
import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';

const WhoHasRight = () => {
  const hasRight = [
    'Trabalhadores CLT (carteira assinada)',
    'Trabalhadores MEI (Microempreendedor Individual)',
    'Trabalhadores rurais',
    'Contribuintes individuais',
    'Quem sofreu acidente de trabalho ou doença ocupacional',
    'Quem possui sequela permanente que reduz capacidade de trabalho'
  ];

  const noRight = [
    'Aposentados por invalidez',
    'Quem não possui incapacidade permanente',
    'Quem nunca contribuiu para o INSS',
    'Aposentados por idade ou tempo de contribuição',
    'Quem teve recuperação total sem sequelas',
    'Servidores públicos estatutários'
  ];

  return (
    <section id="quem-tem-direito" className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Quem Tem Direito ao Auxílio-Acidente?
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white p-8 rounded-2xl shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-emerald-600 p-2 rounded-full">
                <Check className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">Tem Direito</h3>
            </div>
            <ul className="space-y-4">
              {hasRight.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <Check className="text-emerald-600 flex-shrink-0 mt-1" size={20} />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white p-8 rounded-2xl shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-red-600 p-2 rounded-full">
                <X className="text-white" size={24} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">Não Tem Direito</h3>
            </div>
            <ul className="space-y-4">
              {noRight.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <X className="text-red-600 flex-shrink-0 mt-1" size={20} />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhoHasRight;