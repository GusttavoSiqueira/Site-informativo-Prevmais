import React, { useState } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { MessageSquare, Send, X, User, Phone, ClipboardList } from 'lucide-react';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';

    const LeadCaptureForm = () => {
      const [isOpen, setIsOpen] = useState(false);
      const [formData, setFormData] = useState({
        name: '',
        phone: '',
        message: '',
      });
      const { toast } = useToast();

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name || !formData.phone) {
          toast({
            title: 'Campos obrigatórios',
            description: 'Por favor, preencha seu nome e telefone.',
            variant: 'destructive',
          });
          return;
        }

        console.log('Dados capturados:', formData);
        const leads = JSON.parse(localStorage.getItem('leads') || '[]');
        leads.push(formData);
        localStorage.setItem('leads', JSON.stringify(leads));

        toast({
          title: 'Informações enviadas!',
          description: 'Você será redirecionado para o WhatsApp.',
        });

        const whatsappMessage = `Olá, meu nome é ${formData.name} e gostaria de falar com um especialista da PREV+. Meu telefone é ${formData.phone} e meu caso é: ${formData.message}`;
        const whatsappUrl = `https://wa.me/5511921167221?text=${encodeURIComponent(whatsappMessage)}`;
        
        window.open(whatsappUrl, '_blank');
        
        setFormData({ name: '', phone: '', message: '' });
        setIsOpen(false);
      };
      
      const formVariants = {
        hidden: { opacity: 0, y: 50, scale: 0.9 },
        visible: { 
          opacity: 1, 
          y: 0, 
          scale: 1,
          transition: { type: "spring", stiffness: 120, damping: 15 } 
        },
        exit: { opacity: 0, y: 50, scale: 0.9, transition: { duration: 0.3 } },
      };

      return (
        <>
          <motion.button
            onClick={() => setIsOpen(!isOpen)}
            className="fixed bottom-24 right-6 bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-full shadow-2xl z-50 flex items-center gap-2 transition-all hover:scale-110"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            animate={{ 
              scale: [1, 1.05, 1],
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <MessageSquare size={32} />
          </motion.button>
          
          <AnimatePresence>
            {isOpen && (
              <motion.div
                variants={formVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="fixed bottom-6 right-6 md:bottom-auto md:top-1/2 md:-translate-y-1/2 md:right-6 w-[calc(100%-3rem)] max-w-sm bg-white rounded-2xl shadow-2xl z-50 p-6 border border-gray-200"
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold text-gray-900">Fale com um Especialista</h3>
                  <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-800">
                    <X size={24} />
                  </button>
                </div>
                <p className="text-gray-600 mb-6">Envie seu caso e receba atendimento gratuito!</p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <Input type="text" name="name" placeholder="Nome completo*" value={formData.name} onChange={handleInputChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <Input type="tel" name="phone" placeholder="Telefone/WhatsApp*" value={formData.phone} onChange={handleInputChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                     <ClipboardList className="absolute left-3 top-4 text-gray-400" size={20} />
                    <Textarea name="message" placeholder="Conte-nos o que aconteceu, local do acidente e detalhes importantes do seu caso." value={formData.message} onChange={handleInputChange} className="pl-10" rows={4} />
                  </div>

                  <Button type="submit" className="w-full bg-emerald-600 text-white hover:bg-emerald-700 font-semibold text-lg py-6">
                    <Send className="mr-2" size={20} />
                    Enviar e Falar com Especialista
                  </Button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      );
    };

    export default LeadCaptureForm;