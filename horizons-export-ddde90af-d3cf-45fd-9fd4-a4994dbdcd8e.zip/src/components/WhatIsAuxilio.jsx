import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Heart, DollarSign } from 'lucide-react';

const WhatIsAuxilio = () => {
  const features = [
    {
      icon: Briefcase,
      title: 'Benefício Trabalhista',
      description: 'Destinado a trabalhadores que sofreram acidente de trabalho ou doença ocupacional'
    },
    {
      icon: Heart,
      title: 'Sequela Permanente',
      description: 'Para quem ficou com redução da capacidade laborativa de forma definitiva'
    },
    {
      icon: DollarSign,
      title: 'Renda Vitalícia',
      description: 'Pagamento mensal que você recebe mesmo continuando a trabalhar'
    }
  ];

  return (
    <section id="beneficios" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            O que é o Auxílio-Acidente?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            É um benefício pago pelo INSS a trabalhadores que sofreram acidente e ficaram com sequelas permanentes que reduzem sua capacidade de trabalho.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="bg-gradient-to-br from-emerald-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="bg-emerald-600 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <feature.icon className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhatIsAuxilio;