import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Calendar, Wallet } from 'lucide-react';

const ValueRetroactivity = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-emerald-600 to-emerald-700">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Auxílio-Acidente Retroativo: Você pode receber valores atrasados!
          </h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Entenda quanto você pode receber mensalmente e os valores retroativos desde a cessação do auxílio-doença.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-white/20"
          >
            <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Wallet className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Valor Mensal</h3>
            <p className="text-white/90 text-lg leading-relaxed">
              Você recebe 50% do salário de benefício, calculado com base nas suas contribuições ao INSS.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-white/20"
          >
            <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Calendar className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Pagamento Retroativo</h3>
            <p className="text-white/90 text-lg leading-relaxed">
              Você pode receber valores atrasados desde a data do acidente ou da cessação do auxílio-doença, se não foi concedido na época correta.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-white/20"
          >
            <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <TrendingUp className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Renda Vitalícia</h3>
            <p className="text-white/90 text-lg leading-relaxed">
              O benefício é pago mensalmente de forma vitalícia, mesmo que você continue trabalhando.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ValueRetroactivity;