import React from 'react';
import { motion } from 'framer-motion';
import { User, ClipboardCheck, Gavel } from 'lucide-react';
import { Button } from '@/components/ui/button';

const RealExamples = () => {
  const examples = [
    {
      icon: ClipboardCheck,
      title: 'Exemplo Prático Nº 1: Maria',
      case: 'Maria sofreu um acidente de moto e perdeu parte da mobilidade da perna. Nunca precisou se afastar do trabalho com auxílio-doença. Mesmo assim, conseguiu o Auxílio-Acidente diretamente ao comprovar sua limitação funcional com a PREV+.',
      highlight: 'Se você sofreu um acidente e ficou com sequelas, mesmo sem ter recebido o auxílio-doença, pode ter direito ao benefício!'
    },
    {
      icon: Gavel,
      title: 'Exemplo Prático Nº 2: João',
      case: 'João sofreu um acidente e recebeu auxílio-doença por 6 meses. Ao retornar ao trabalho, continuou com sequelas. O INSS não concedeu o auxílio-acidente automaticamente. Após recorrer na Justiça com a PREV+, João recebeu todos os valores atrasados desde o fim do auxílio-doença.',
      highlight: 'A PREV+ garante que você receba todos os valores devidos, inclusive os retroativos!'
    }
  ];

  const handleWhatsApp = () => {
    window.open('https://wa.me/5511999999999?text=Olá! Gostaria de saber mais sobre o Auxílio-Acidente.', '_blank');
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Exemplos Reais de Sucesso
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Veja como a PREV+ já ajudou pessoas como você a conquistar seus direitos
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {examples.map((example, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="bg-gradient-to-br from-emerald-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-emerald-600 w-16 h-16 rounded-full flex items-center justify-center">
                  <example.icon className="text-white" size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">{example.title}</h3>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-gray-700 leading-relaxed">{example.case}</p>
                </div>
                
                <div className="bg-emerald-100 p-4 rounded-lg">
                  <p className="text-emerald-800 leading-relaxed font-semibold">{example.highlight}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Button
            onClick={handleWhatsApp}
            size="lg"
            className="bg-emerald-600 text-white hover:bg-emerald-700 text-lg px-8 py-6 font-semibold"
          >
            Falar com um advogado especialista agora!
          </Button>
        </div>
      </div>
    </section>
  );
};

export default RealExamples;