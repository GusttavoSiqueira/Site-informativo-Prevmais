import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, Award } from 'lucide-react';

const AboutPrev = () => {
  const cardVariants = {
    offscreen: {
      y: 50,
      opacity: 0
    },
    onscreen: (i) => ({
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        bounce: 0.4,
        duration: 0.8,
        delay: i * 0.2
      }
    })
  };

  return (
    <section id="quem-somos" className="py-20 md:py-28 bg-slate-50 overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
            A <span className="text-emerald-600">PREV+</span> ao seu lado
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Somos especialistas em transformar burocracia em tranquilidade, garantindo seus direitos com agilidade e segurança.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-8"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-video">
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/hnPKgmgg0G4"
                title="Vídeo Institucional PREV+"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-800 mb-4">Por que confiar na gente?</h3>
              <p className="text-gray-700 leading-relaxed">
                A PREV+ é sua parceira na busca por benefícios previdenciários. Com uma equipe de especialistas e atendimento humanizado, cuidamos de todo o processo para que você tenha a segurança e a agilidade que merece. Atuamos com transparência, ética e compromisso, focados em garantir o melhor resultado para você.
              </p>
            </div>
          </motion.div>

          <div className="space-y-6">
            <motion.div
              custom={0}
              variants={cardVariants}
              initial="offscreen"
              whileInView="onscreen"
              viewport={{ once: true, amount: 0.5 }}
              className="p-6 rounded-2xl bg-white border border-gray-200/80 shadow-sm hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center gap-4">
                <div className="bg-emerald-100 p-3 rounded-lg">
                  <Shield className="text-emerald-600" size={24} />
                </div>
                <h4 className="font-bold text-xl text-gray-900">Nossa Missão</h4>
              </div>
              <p className="text-gray-600 mt-3">Garantir que seus direitos sejam respeitados com total segurança e transparência, transformando vidas.</p>
            </motion.div>

            <motion.div
              custom={1}
              variants={cardVariants}
              initial="offscreen"
              whileInView="onscreen"
              viewport={{ once: true, amount: 0.5 }}
              className="p-6 rounded-2xl bg-white border border-gray-200/80 shadow-sm hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center gap-4">
                <div className="bg-emerald-100 p-3 rounded-lg">
                  <Users className="text-emerald-600" size={24} />
                </div>
                <h4 className="font-bold text-xl text-gray-900">Nossa Visão</h4>
              </div>
              <p className="text-gray-600 mt-3">Ser a maior referência em consultoria previdenciária do Brasil, reconhecida pela excelência e resultados.</p>
            </motion.div>

            <motion.div
              custom={2}
              variants={cardVariants}
              initial="offscreen"
              whileInView="onscreen"
              viewport={{ once: true, amount: 0.5 }}
              className="p-6 rounded-2xl bg-white border border-gray-200/80 shadow-sm hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center gap-4">
                <div className="bg-emerald-100 p-3 rounded-lg">
                  <Award className="text-emerald-600" size={24} />
                </div>
                <h4 className="font-bold text-xl text-gray-900">Nossos Valores</h4>
              </div>
              <p className="text-gray-600 mt-3">Confiança, ética, dedicação total ao cliente e foco incansável em resultados positivos.</p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPrev;